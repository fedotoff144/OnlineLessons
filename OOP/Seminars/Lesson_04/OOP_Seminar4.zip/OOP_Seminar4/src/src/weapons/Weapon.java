package weapons;

public interface Weapon {
    int damage();
}
