package items;

public interface DistanceAttacker {
    int getDistance();
}
