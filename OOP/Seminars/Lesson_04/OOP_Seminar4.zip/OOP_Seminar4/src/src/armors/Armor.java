package armors;

import java.util.Random;

public interface Armor {
    Random rnd = new Random();
    int protection();
}
