package Lesson_04.team;

import java.util.ArrayList;
import java.util.List;

import Lesson_04.items.DistanceAttacker;
import Lesson_04.items.Warrior;

public class Team<T extends Warrior> { //можно поставить только наследников класса Warrior
    private List<T> team = new ArrayList<>();
    private String name;

    public Team(String name) {
        this.name = name;
    }

    public Team<T> addWarrior(T warrior) {
        team.add(warrior);
        return this;
    }

    public int getMaxDistance(){
        int distance = 0;
        for (T item : team) {
            if (!(item instanceof DistanceAttacker)){
                continue;
            }
            DistanceAttacker tmp = (DistanceAttacker)item;
            if(tmp.getDistance() > distance){
                distance = tmp.getDistance();
            }
            }            
        return distance;
    }

    @Override
    public String toString() {
        StringBuilder teamBuilder = new StringBuilder();
        for (T item : team) {
            teamBuilder.append(item.toString()+'\n');
        }
        return String.format("Team {team: %s, maxdistance = %d,  %s}", name, getMaxDistance(), teamBuilder);
    }

}
