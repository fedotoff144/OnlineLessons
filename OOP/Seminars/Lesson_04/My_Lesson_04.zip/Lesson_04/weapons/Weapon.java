package Lesson_04.weapons;

public interface Weapon {
    
    public int Damage();
}
