package Lesson_04.weapons;

public class Bow implements Weapon {
    private int distance = 30;

    public int getDistance(){
        return distance;
    }
    public int Damage(){
        return 50;
    }
    @Override
    public String toString() {
        return "Bow [distance = " + distance + " damage = " + Damage() + "]";
    }
}
