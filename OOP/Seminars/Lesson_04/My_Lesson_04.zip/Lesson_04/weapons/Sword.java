package Lesson_04.weapons;

public class Sword implements Weapon{
    public int Damage(){
        return 50;
    }

    @Override
    public String toString() {
        return "Damage sword = " + Damage();
    }
    
}
