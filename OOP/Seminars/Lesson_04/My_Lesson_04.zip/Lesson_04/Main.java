package Lesson_04;

import Lesson_04.items.Archer;
import Lesson_04.items.SwordMan;
import Lesson_04.items.Warrior;
import Lesson_04.team.Team;
import Lesson_04.weapons.Bow;
import Lesson_04.weapons.Sword;

public class Main {
    public static void main(String[] args) {
        Team<Archer> archerTeam = new Team<>("Archers");
        archerTeam.addWarrior(new Archer("Vasya", new Bow()))
                .addWarrior(new Archer("Semen", new Bow()))
                .addWarrior(new Archer("Petya", new Bow()))
                .addWarrior(new Archer("Ivan", new Bow()));

        System.out.println(archerTeam);

        Team<Warrior> mixTeam = new Team<>("Mixer");
        mixTeam.addWarrior(new Archer("Ruslan", new Bow()))
        .addWarrior(new SwordMan("Oleg", new Sword()))
        .addWarrior(new Archer("Fedya", new Bow()))
        .addWarrior(new SwordMan("Vyatich", new Sword()));

        System.out.println(mixTeam);
    }
}