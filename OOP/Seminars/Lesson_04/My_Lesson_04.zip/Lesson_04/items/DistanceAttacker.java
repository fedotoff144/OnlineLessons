package Lesson_04.items;

public interface DistanceAttacker {
    int getDistance();
}
