package Lesson_04.items;

import java.util.Random;
import Lesson_04.weapons.Weapon;

public abstract class Warrior<T extends Weapon> {

    private String name;
    protected T weapon;
    protected Random rnd = new Random();
    private int healthPoint;

    public Warrior(String name, T weapon) {
        this.name = name;
        this.weapon = weapon;
        healthPoint = 100;
    }

    public abstract int hitDamage();

    public int maxDamage() {
        return weapon.Damage();
    }

    @Override
    public String toString() {
        return "Warrior [name=" + name + ", weapon=" + weapon + ", healthPoint=" + healthPoint + "]";
    }
}
