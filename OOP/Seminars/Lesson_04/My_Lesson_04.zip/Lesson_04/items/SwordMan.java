package Lesson_04.items;

import Lesson_04.weapons.Sword;

public class SwordMan extends Warrior<Sword> {

    public SwordMan(String name, Sword weapon) {
        super(name, weapon);
    }

    @Override
    public int hitDamage() {
        return rnd.nextInt(weapon.Damage());
    }

    @Override
    public String toString() {
        return super.toString() + " SwordMan";
    }
}
