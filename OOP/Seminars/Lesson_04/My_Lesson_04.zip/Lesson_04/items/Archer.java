package Lesson_04.items;

import Lesson_04.weapons.Bow;

public class Archer extends Warrior<Bow> implements DistanceAttacker {
    private int distance;

    public Archer(String name, Bow weapon) {
        super(name, weapon);

        distance = weapon.Damage() + rnd.nextInt(10);
    }
    public int getDistance(){
        return distance;
    }

    @Override
    public int hitDamage() {
        return rnd.nextInt(weapon.Damage());
    }

    @Override
    public String toString() {
        return super.toString() + "'\n'Archer {distance " + distance + "}";
    }
}
