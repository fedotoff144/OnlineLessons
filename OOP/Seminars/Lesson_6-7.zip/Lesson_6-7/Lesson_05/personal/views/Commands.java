package Lesson_05.personal.views;

public enum Commands {
    NONE,
    READ,
    CREATE,
    UPDATE,
    LIST,
    DELETE,
    EXIT
}