package solid.ocp;

public interface Shape {
    double getArea();
}
