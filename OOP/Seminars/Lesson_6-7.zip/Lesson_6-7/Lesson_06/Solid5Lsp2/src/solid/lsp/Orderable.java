package solid.lsp;

public interface Orderable {
    int getAmount();
}
