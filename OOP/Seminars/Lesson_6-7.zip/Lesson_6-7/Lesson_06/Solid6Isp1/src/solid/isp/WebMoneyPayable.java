package solid.isp;

public interface WebMoneyPayable {
    void payWebMoney(int amount);
}
