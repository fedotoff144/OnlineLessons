package solid.isp;

public interface CreditCardPayable {
    void payCreditCard(int amount);
}
