package solid.isp;

public interface PhoneNumberPayable {
    void payPhoneNumber(int amount);
}
