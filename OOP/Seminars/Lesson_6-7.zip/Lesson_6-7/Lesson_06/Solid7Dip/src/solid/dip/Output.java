package solid.dip;

import java.util.List;

public interface Output {
    void output(List<ReportItem> items);
}
