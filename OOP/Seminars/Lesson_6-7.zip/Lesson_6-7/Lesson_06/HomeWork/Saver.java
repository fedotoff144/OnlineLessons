public interface Saver {
    void save();
}
