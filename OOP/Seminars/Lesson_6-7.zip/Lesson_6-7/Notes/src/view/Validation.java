package view;

import model.Note;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Validation {
    Pattern textPattern = Pattern.compile("^\\S+$");

    public void validateNote(Note inputNote) throws Exception{
        Matcher textMatcher = textPattern.matcher(inputNote.getText());
        Matcher headerMatcher = textPattern.matcher(inputNote.getHeader());

        if(!textMatcher.find(0)){
            throw new Exception("");
        }
        if(!headerMatcher.find(0)){
            throw new Exception("");
        }
    }
}
